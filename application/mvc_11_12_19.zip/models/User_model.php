<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* Name:  User Model
*
*
* Created:  18.09.2017
*
*
* Requirements: PHP5 or above
*
*/

class User_model extends CI_Model
{
	/**
	 * Holds name of tables used
	 *
	 * @var string
	 **/
	protected $tables;

	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		// initialize db tables data
		$this->tables  = 'users';
	}

	/**
	 * Get All admin Users stored in the database.
	 *
	 * @return object
	 * 
	 **/
	 
	public function get_AdminUsers()
	{
		$this->db->from($this->tables);
		$this->db->select("*");
		$this->db->where('role_id != 4');
		$query = $this->db->get();        
		return $query->result();
	}

	/**
	 * Get All site Users stored in the database.
	 * 
	 *
	 * @return object
	 *
	 **/
	 
	public function get_SiteUsers()
	{
		$this->db->from($this->tables);
		$this->db->select("*");
		$this->db->where('role_id = 5');
		$query = $this->db->get();        
		return $query->result();
	}
	
	/**
	* removeUserFromContact()
	* Remove User From Contact
	*/

	public function removeUserFromContactFriends($remove_id){
		$userid = $this->session->userdata('user_id');
		$result = $this->db->query('SELECT * FROM user_contacts WHERE user_id='.$remove_id.' OR contact_id='.$remove_id)->row();	
		if($result){
			$this->db->where('id', $result->id);
			$result = $this->db->delete('user_contacts');
		}
		$result = $this->db->query('SELECT * FROM user_contact_request WHERE user_id='.$remove_id.' OR contact_id='.$remove_id)->row();	
		if($result){
			$this->db->where('id', $result->id);
			$result = $this->db->delete('user_contact_request');
		}
		$result = $this->db->query('SELECT * FROM user_friends WHERE user_id='.$remove_id.' OR friend_id='.$remove_id)->row();	
		if($result){
			$this->db->where('id', $result->id);
			$result = $this->db->delete('user_friends');
		}
	}



}

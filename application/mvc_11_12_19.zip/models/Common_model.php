<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
	class Common_model extends CI_Model {

		public $table_name;
		
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function updateStatus($data = null){
			$user_id          = $this->session->userdata('user_id');
			$this->table_name = $this->getTableName($data['type']);

			$savedata = array(
				'updated_by' => $user_id,
				'updated_at' => date('Y-m-d H:i:s'),
				'status'     => $data['new_status']
			);
			
			$this->db->where('id', $data['id']);
            $result = $this->db->update($this->table_name, $savedata);
			if($result){
		        return true;
			}else{
				return false;
			}
		}

		public function getTableName($type = null){
			switch ($type) {
				case "Post":
					return "post";
					break;
				case "Post_Comment":
					return "post_comment";
					break;
			  	case "Image_comment":
					return "image_comment";
					break;
				case "Event_Comment":
					return "event_comment";
					break;
				case "media":
					return "media_gallery_category";
					break;
				case "art":
					return "art_gallery_category";
					break;
				case "Event":
					return "events";
					break;
				case "User_Profile":
					return "users_profile";
					break;
				case "meet_date":
					return "meet_date_category";
					break;	
				case "Media_video":
				    return "media_video";
				    break;
				case "Media_video_comment":
				    return "media_video_comment";
				    break;
				case "Media_Channel":
				    return "media_channel";
				    break;
				case "Art_Wall":
				    return "art_wall";
				    break;
				case "Wall_Art":
				    return "wall_arts";
				    break;
				case "Wall_Art_Comment":
				    return "wall_arts_comment";
				    break;  
				case "Advertisement":
				    return "advertisement";
				    break;
				case "Product":
				    return "store_products";
				    break;	
				case "Store":
				    return "store";
				    break;		
				case "Group":
				    return "groups";
				    break;
				case "Group_Post":
				    return "group_posts";
				    break;		
				default:
					break;
			}
		}

		public function count_post_list(){
			return $this->db->count_all_results('post');
		}

		public function count_media_list(){
			return $this->db->count_all_results('media_video');
		}
		
		public function count_art_list(){
			return $this->db->count_all_results('wall_arts');  // Produces an integer, like 25
		}
		
		public function count_wall_list(){
			return $this->db->count_all_results('art_wall');  // Produces an integer, like 25
		}

		public function count_events_list(){
			return $this->db->count_all_results('events');  //
		}
		
		public function count_product_list(){
			return $this->db->count_all_results('store_products');
		}
		public function count_store_list(){
			return $this->db->count_all_results('store');
		}
		public function count_groups_list(){
			return $this->db->count_all_results('groups');
		}
		public function count_pages_list(){
			return $this->db->count_all_results('pages');
		}

		public function getTotalReportContentCount(){
			$this->db->select('count(`id`) as total_report, content_type');
			$this->db->from('reported_content');
			$this->db->group_by('content_type');
			$query = $this->db->get(); 
			return $query->result();
		}

		public function getTotalReadReportContent($content_type){
			$this->db->select('count(`id`) as total_read');
			$this->db->from('reported_content');
			$this->db->where('content_type', $content_type);
			$this->db->where('isReviewed', 1);
			$this->db->group_by('content_type');
			$query = $this->db->get(); 
			return $query->row();
		}

		#delete image & other subcomponent(likes, comment, views)
		public function delete_image_with_component($image_id,$image_folder,$image_folder_full=false){
             $get_image = $this->db->query('SELECT * FROM image WHERE id='.$image_id)->row();
             if(!empty($get_image)){

             	if(!$image_folder_full){
                 $img_name = $image_folder.$get_image->prefix.'image_'.$get_image->id.'.'.strtolower($get_image->type);
             	}
             	else{
             	 $img_name = $image_folder;
             	}

                if (file_exists($this->config->item('parent_folder_name').$img_name)){
                    unlink($this->config->item('parent_folder_name').$img_name);
                }

                $this->db->where('id', $get_image->id);
                $this->db->delete('image');

                #delete image like,view,comment
                $get_image_comment = $this->db->query('SELECT * FROM image_comment WHERE image_id='.$get_image->id)->result();
                if(count($get_image_comment)>0){
                    foreach ($get_image_comment as $record) {
                        $this->db->where('id', $record->id);
                        $this->db->delete('image_comment');
                   }
                }

                $get_image_like = $this->db->query('SELECT * FROM image_like WHERE image_id='.$get_image->id)->result();
                if(count($get_image_like)>0){
                    foreach ($get_image_like as $record) {
                       $this->db->where('id', $record->id);
                       $this->db->delete('image_like');
                   }
                }

                $get_image_views = $this->db->query('SELECT * FROM image_views WHERE image_id='.$get_image->id)->result();
                if(count($get_image_views)>0){
                    foreach ($get_image_views as $record) {
                       $this->db->where('id', $record->id);
                       $this->db->delete('image_views');
                    }
                }
             }
		}
}
?>
